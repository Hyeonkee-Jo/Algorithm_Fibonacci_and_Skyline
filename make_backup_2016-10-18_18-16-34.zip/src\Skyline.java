import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by jo930_000 on 2016-10-18.
 */
public class Skyline {

    ArrayList<Line> skyline = new ArrayList<Line>();
    Building[] building;

    public class Building {
        int left, heigth, right;

        public Building() {
            this.left = 0;
            this.heigth = 0;
            this.right = 0;
        }

        public Building(int left, int height, int right) {
            this.left = left;
            this.heigth = height;
            this.right = right;
        }
    }

    public class Line {
        int left, height;

        public Line() {
            this.left = 0;
            this.height = 0;
        }

        public Line(int left, int height) {
            this.left = left;
            this.height = height;
        }

        public String toString() {
            return this.left + ", " + this.height;
        }
    }

    public void build_constructor(int n) {
        Building[] building = new Building[n];

        for(int i = 0 ; i < n; i++) {
            building[i] = new Building();
        }
    }

    public ArrayList<Line> find_skyline(Building[] build, int start, int end) {
        if( start == end ) {
            skyline.add(new Line(build[start].left, build[start].heigth)); // append skyline
            skyline.add(new Line(build[end].right, 0));
            return skyline;
        }

        int mid = ( start + 2 ) / 2;
        ArrayList<Line> sky1 = this.find_skyline(build, start, mid);
        ArrayList<Line> sky2 = this.find_skyline(build, mid+1, end);
        return merge_skyline(sky1, sky2);
    }

    public ArrayList<Line> merge_skyline(ArrayList<Line> sky1, ArrayList<Line> sky2) {
        int current_height1 = 0;
        int current_height2 = 0;
        int current_x, max_h;

        while(sky1.size()>0 && sky2.size()>0) {
            if(sky1.get(0).left < sky2.get(0).left) {
                current_x = sky1.get(0).left;
                current_height1 = sky1.get(0).height;
                max_h = current_height1;

                if(current_height2 > max_h) {
                    max_h = current_height2;
                    skyline.add(new Line(current_x, max_h));
                    sky1.remove(0);
                }
            }

            else {
                current_x = sky2.get(0).left;
                current_height2 = sky2.get(0).height;
                max_h = current_height1;

                if(current_height2 > max_h) {
                    max_h = current_height2;
                    skyline.add(new Line(current_x, max_h));
                    sky2.remove(0);
                }
            }
        }

        while(sky1.size() > 0) {
            skyline.add(new Line(sky1.get(0).left, sky1.get(0).height));
            sky1.remove(0);
        }

        while(sky2.size() > 0) {
            skyline.add(new Line(sky2.get(0).left, sky2.get(0).height));
            sky2.remove(0);
        }

        return skyline;
    }

}
